// // // // // // // 


// // // // // // import React, { useState } from "react";
// // // // // // import { View, Picker, StyleSheet } from "react-native";

// // // // // // const App = () => {
// // // // // //   const [selectedValue, setSelectedValue] = useState("java");
// // // // // //   return (
// // // // // //     <View style={styles.container}>
// // // // // //       <Picker
// // // // // //         selectedValue={selectedValue}
// // // // // //         style={{ height: 50, width: 150 }}
// // // // // //         onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}
// // // // // //       >
// // // // // //         <Picker.Item label="Java" value="java" />
// // // // // //         <Picker.Item label="JavaScript" value="js" />
// // // // // //       </Picker>
// // // // // //     </View>
// // // // // //   );
// // // // // // }

// // // // // // const styles = StyleSheet.create({
// // // // // //   container: {
// // // // // //     flex: 1,
// // // // // //     paddingTop: 40,
// // // // // //     alignItems: "center"
// // // // // //   }
// // // // // // });

// // // // // // export default App;




// // // // // // import React, { Component, Fragment } from 'react';
// // // // // // import SearchableDropdown from 'react-native-searchable-dropdown';
// // // // // // import {Image,Text} from 'react-native';

// // // // // // var items = [
// // // // // //   {
// // // // // //     id: 1,
// // // // // //     name: 'JavaScript',
// // // // // //     Image:require("../assets/img.jpg"),
// // // // // //   },
// // // // // //   {
// // // // // //     id: 2,
// // // // // //     name: 'Java',

// // // // // //   },
// // // // // //   {
// // // // // //     id: 3,
// // // // // //     name: 'Ruby',
// // // // // //   },
// // // // // //   {
// // // // // //     id: 4,
// // // // // //     name: 'React Native',
// // // // // //   },
// // // // // //   {
// // // // // //     id: 5,
// // // // // //     name: 'PHP',
// // // // // //   },
// // // // // //   {
// // // // // //     id: 6,
// // // // // //     name: 'Python',
// // // // // //   },
// // // // // //   {
// // // // // //     id: 7,
// // // // // //     name: 'Go',
// // // // // //   },
// // // // // //   {
// // // // // //     id: 8,
// // // // // //     name: 'Swift',
// // // // // //   },
// // // // // // ];
// // // // // // export default class App extends React.Component {
// // // // // //   constructor(props) {
// // // // // //     super(props);
// // // // // //     this.state = {
// // // // // //       selectedItems: [
// // // // // //         {
// // // // // //           id: 7,
// // // // // //           name: 'Go',
// // // // // //         },
// // // // // //         {
// // // // // //           id: 8,
// // // // // //           name: 'Swift',
// // // // // //         }
// // // // // //       ],
// // // // // //       name:'',
// // // // // //       email:'',
// // // // // //       search_text:"Search Here",
// // // // // //     }
// // // // // //   }
// // // // // //   render() {
// // // // // //     return (
// // // // // //       <Fragment>
// // // // // //         {/* Multi */}
// // // // // //        <SearchableDropdown
// // // // // //           multi={true}
// // // // // //           selectedItems={this.state.selectedItems}
// // // // // //           onItemSelect={(item) => {
// // // // // //             const items = this.state.selectedItems;
// // // // // //             items.push(item)
// // // // // //             this.setState({ selectedItems: items });
// // // // // //           }}
// // // // // //           containerStyle={{ padding: 5 }}
// // // // // //           onRemoveItem={(item, index) => {
// // // // // //             const items = this.state.selectedItems.filter((sitem) => sitem.id !== item.id);
// // // // // //             this.setState({ selectedItems: items });
// // // // // //           }}
// // // // // //           itemStyle={{
// // // // // //             padding: 10,
// // // // // //             marginTop: 2,
// // // // // //             backgroundColor: '#ddd',
// // // // // //             borderColor: '#bbb',
// // // // // //             borderWidth: 1,
// // // // // //             borderRadius: 5,
// // // // // //           }}
// // // // // //           itemTextStyle={{ color: '#222' }}
// // // // // //           itemsContainerStyle={{ maxHeight: 140 }}
// // // // // //           items={items}
// // // // // //           defaultIndex={2}
// // // // // //           chip={true}
// // // // // //           resetValue={false}
// // // // // //           textInputProps={
// // // // // //             {
// // // // // //               placeholder: "placeholder",
// // // // // //               underlineColorAndroid: "transparent",
// // // // // //               style: {
// // // // // //                 padding: 12,
// // // // // //                 borderWidth: 1,
// // // // // //                 borderColor: '#ccc',
// // // // // //                 borderRadius: 5,
// // // // // //               },
// // // // // //               onTextChange: text => alert(text)
// // // // // //             }
// // // // // //           }
// // // // // //           listProps={
// // // // // //             {
// // // // // //               nestedScrollEnabled: true,
// // // // // //             }
// // // // // //           }
// // // // // //         /> 
// // // // // //         {/* Single */}
// // // // // //         <SearchableDropdown
// // // // // //           onItemSelect={(item) => {
// // // // // //             const items = this.state.selectedItems;
// // // // // //             items.push(item)
// // // // // //             this.setState({ selectedItems: items, search_text: item.name, });
// // // // // //           }}
// // // // // //           containerStyle={{ padding: 5 }}
// // // // // //           onRemoveItem={(item, index) => {
// // // // // //             const items = this.state.selectedItems.filter((sitem) => sitem.id !== item.id);
// // // // // //             this.setState({ selectedItems: items });
// // // // // //           }}
// // // // // //           itemStyle={{
// // // // // //             padding: 10,
// // // // // //             marginTop: 2,
// // // // // //             backgroundColor: '#ddd',
// // // // // //             borderColor: '#bbb',
// // // // // //             borderWidth: 1,
// // // // // //             borderRadius: 5,
// // // // // //           }}
// // // // // //           itemTextStyle={{ color: '#222' }}
// // // // // //           itemsContainerStyle={{ maxHeight: 140 }}
// // // // // //           items={items}
// // // // // //           defaultIndex={2}
// // // // // //           resetValue={true}

// // // // // //           textInputProps={
// // // // // //             {
// // // // // //               placeholder:this.state.search_text,
// // // // // //               underlineColorAndroid: "transparent",
// // // // // //               style: {
// // // // // //                 padding: 12,
// // // // // //                 borderWidth: 1,
// // // // // //                 borderColor: '#ccc',
// // // // // //                 borderRadius: 5,
// // // // // //               },
// // // // // //               onTextChange: text =>this.setState({ search_text: text })
// // // // // //             }
// // // // // //           }
// // // // // //           // listProps={
// // // // // //           //   {
// // // // // //           //     nestedScrollEnabled: true,
// // // // // //           //   }
// // // // // //           // }
// // // // // //         />


// // // // // //         <Text>{items.name}</Text>
// // // // // //       </Fragment>
// // // // // //     );
// // // // // //   }
// // // // // // }




// // // // // // Example of Searchable Dropdown / Picker in React Native
// // // // // // https://aboutreact.com/example-of-searchable-dropdown-picker-in-react-native/

// // // // // // import React in our code
// // // // // import React, {useState, useEffect} from 'react';

// // // // // // import all the components we are going to use
// // // // // import {SafeAreaView, StyleSheet, Text, View} from 'react-native';

// // // // // // import SearchableDropdown component
// // // // // import SearchableDropdown from 'react-native-searchable-dropdown';

// // // // // // Item array for the dropdown
// // // // // const items = [
// // // // //   // name key is must. It is to show the text in front
// // // // //   {id: 1, name: 'angellist'},
// // // // //   {id: 2, name: 'codepen'},
// // // // //   {id: 3, name: 'envelope'},
// // // // //   {id: 4, name: 'etsy'},
// // // // //   {id: 5, name: 'facebook'},
// // // // //   {id: 6, name: 'foursquare'},
// // // // //   {id: 7, name: 'github-alt'},
// // // // //   {id: 8, name: 'github'},
// // // // //   {id: 9, name: 'gitlab'},
// // // // //   {id: 10, name: 'instagram'},
// // // // // ];

// // // // // const Test = () => {
// // // // //   // Data Source for the SearchableDropdown
// // // // //   const [serverData, setServerData] = useState([]);

// // // // //   // useEffect(() => {
// // // // //   //   fetch('https://aboutreact.herokuapp.com/demosearchables.php')
// // // // //   //     .then((response) => response.json())
// // // // //   //     .then((responseJson) => {
// // // // //   //       //Successful response from the API Call
// // // // //   //       setServerData(responseJson.results);
// // // // //   //     })
// // // // //   //     .catch((error) => {
// // // // //   //       console.error(error);
// // // // //   //     });
// // // // //   // }, []);
// // // // //   const [selectedValue, setSelectedValue] = useState("");
// // // // //   return (
// // // // //     <SafeAreaView style={styles.container}>
// // // // //       <View style={styles.container}>
// // // // //         <Text style={styles.titleText}>
// // // // //           Example of Searchable Dropdown / Picker in React Native
// // // // //         </Text>
// // // // //         <Text style={styles.headingText}>
// // // // //           Searchable Dropdown from Static Array
// // // // //         </Text>
// // // // //         <SearchableDropdown
// // // // //          onTextChange={(text) => console.log(text)}
// // // // //           // Listner on the searchable input
// // // // //           onItemSelect={(item) => setSelectedValue(JSON.stringify(item.name))}
// // // // //           // onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}
// // // // //           // Called after the selection
// // // // //           containerStyle={{padding: 5}}
// // // // //           // Suggestion container style
// // // // //           textInputStyle={{
// // // // //             // Inserted text style
// // // // //             padding: 12,

// // // // //             borderWidth: 1,
// // // // //             borderColor: '#ccc',
// // // // //             backgroundColor: '#FAF7F6',
// // // // //           }}
// // // // //           itemStyle={{
// // // // //             // Single dropdown item style
// // // // //             padding: 10,
// // // // //             marginTop: 2,
// // // // //             backgroundColor: '#FAF9F8',
// // // // //             borderColor: '#bbb',
// // // // //             borderWidth: 1,
// // // // //           }}
// // // // //           itemTextStyle={{
// // // // //             // Text style of a single dropdown item
// // // // //             color: '#222',
// // // // //           }}
// // // // //           itemsContainerStyle={{
// // // // //             // Items container style you can pass maxHeight
// // // // //             // To restrict the items dropdown hieght
// // // // //             maxHeight: '60%',
// // // // //           }}
// // // // //           items={items}
// // // // //           // Mapping of item array
// // // // //           defaultIndex={2}
// // // // //           // Default selected item index
// // // // //           value={selectedValue}
// // // // //           // place holder for the search input
// // // // //           resPtValue={false}
// // // // //           // Reset textInput Value with true and false state
// // // // //           // underlineColorAndroid="transparent"
// // // // //           // To remove the underline from the android input

// // // // //         />



// // // // //         <Text>{selectedValue}</Text>
// // // // //       </View>
// // // // //     </SafeAreaView>
// // // // //   );
// // // // // };

// // // // // export default Test;

// // // // // const styles = StyleSheet.create({
// // // // //   container: {
// // // // //     flex: 1,
// // // // //     backgroundColor: 'white',
// // // // //     padding: 10,
// // // // //   },
// // // // //   titleText: {
// // // // //     padding: 8,
// // // // //     fontSize: 16,
// // // // //     textAlign: 'center',
// // // // //     fontWeight: 'bold',
// // // // //   },
// // // // //   headingText: {
// // // // //     padding: 8,
// // // // //   },
// // // // // });




// // // // // import React, { useState } from 'react'
// // // // // import { Button,StyleSheet,View } from 'react-native'
// // // // // import DatePicker from 'react-native-datepicker'
// // // // // export default () => {
// // // // //   const [date, setDate] = useState('09-10-2020');

// // // // //   return (


// // // // //     <View style={styles.container}>

// // // // //       <DatePicker

// // // // //           date={date} //initial date from state
// // // // //           mode="date" //The enum of date, datetime and time
// // // // //           placeholder="select date"
// // // // //           format="DD-MM-YYYY"
// // // // //           // minDate="01-01-2001"
// // // // //           // maxDate="01-01-20"
// // // // //           confirmBtnText="Confirm"
// // // // //           cancelBtnText="Cancel"
// // // // //           customStyles={{
// // // // //             dateIcon: {
// // // // //               display: 'flex',
// // // // //               position: 'absolute',
// // // // //               left: 0,
// // // // //               top: 4,
// // // // //               marginLeft: 0,

// // // // //             },
// // // // //             // dateInput: {
// // // // //             //   // marginLeft: 36,
// // // // //             // },
// // // // //           }}
// // // // //           onDateChange={(date) => {
// // // // //             setDate(date);
// // // // //           }}
// // // // //         />
// // // // //       </View>

// // // // //   )
// // // // // }


// // // // // const styles = StyleSheet.create({
// // // // //   container: {
// // // // //       flex: 1,
// // // // //       justifyContent: 'center',
// // // // //       alignItems: 'center',
// // // // //   },
// // // // //   title: {
// // // // //     textAlign: 'center',
// // // // //     fontSize: 20,
// // // // //     fontWeight: 'bold',
// // // // //     padding: 20,
// // // // //   },
// // // // //   datePickerStyle: {
// // // // //     width: 200,
// // // // //     marginTop: 20,
// // // // //   },
// // // // // })








// // // // import React, { Component } from "react";
// // // // import { View, Image, Text, StyleSheet } from "react-native";
// // // // import { BlurView } from "@react-native-community/blur";

// // // // export default class Menu extends Component {

// // // //   render() {
// // // //     return (
// // // //       <View style={styles.container}>
// // // //         <Image
// // // //           key={'blurryImage'}
// // // //           source={require('../assets/img1.jpg')}
// // // //           style={styles.absolute}
// // // //         />
// // // //         <Text style={styles.absolute}>Hi, I am some blurred text</Text>
// // // // {/* in terms of positioning and zIndex-ing everything before the BlurView will be blurred */}
// // // //         <BlurView
// // // //           style={styles.absolute}
// // // //           // viewRef={this.state.viewRef}
// // // //           blurType="light"
// // // //           blurAmount={10}
// // // //           reducedTransparencyFallbackColor="white"
// // // //         />
// // // //         <Text>I'm the non blurred text because I got rendered on top of the BlurView</Text>
// // // //       </View>
// // // //     );
// // // //   }
// // // // }

// // // // const styles = StyleSheet.create({
// // // //   container: {
// // // //     justifyContent: "center",
// // // //     alignItems: "center"
// // // //   },
// // // //   absolute: {
// // // //     position: "absolute",
// // // //     top: 0,
// // // //     left: 0,
// // // //     bottom: 0,
// // // //     right: 0
// // // //   }
// // // // });




// // // import React, { useState } from 'react'
// // // import { Text, View, StyleSheet, FlatList, TouchableOpacity,Modal } from 'react-native'
// // // import { AntDesign, Entypo, Ionicons, FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';



// // // const DATA1 = [
// // //     {
// // //         id: '1',
// // //         title: 'This is a Reward of Christmis ',
// // //         description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',
// // //         date: '1 Jan - 2 Feb',
// // //         target: '$100,000',
// // //         stat: 'Prevous',
// // //     },
// // //     {
// // //         id: '2',
// // //         title: 'Reward 2',
// // //         description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',
// // //         date: '1 Jan - 2 Feb',
// // //         target: '$100,000',
// // //         stat: 'Prevous',
// // //     },
// // //     {
// // //         id: '3',
// // //         title: 'Reward 3',
// // //         description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s,',
// // //         date: '1 Jan - 2 Feb',
// // //         target: '$100,000',
// // //         stat: 'Prevous',
// // //     },
// // //     {
// // //         id: '4',
// // //         title: 'Reward 4',
// // //         description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s,',
// // //         date: '1 Jan - 2 Feb',
// // //         target: '$100,000',
// // //         stat: 'Prevous',
// // //     },
// // //     {
// // //         id: '5',
// // //         title: 'Reward 5',
// // //         description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s,',
// // //         date: '1 Jan - 2 Feb',
// // //         target: '$100,000',
// // //         stat: 'Prevous',
// // //     },

// // //     {
// // //         id: '6',
// // //         title: 'Reward 5',
// // //         description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s,',
// // //         date: '1 Jan - 2 Feb',
// // //         target: '$100,000',
// // //         stat: 'Prevous',
// // //     },
// // //     {
// // //         id: '7',
// // //         title: 'Reward 5',
// // //         description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s,',
// // //         date: '1 Jan - 2 Feb',
// // //         target: '$100,000',
// // //         stat: 'Prevous',
// // //     },


// // // ];




// // // export default function Test() {
// // //     const [modalVisible1, setModalVisible1] = useState(false);
// // //     const [rewardName, setRewardName] = useState("null");
// // //     const [rewardTarget, setRewardTarget] = useState("null");
// // //     const [saleTarget, setSaleTarget] = useState(""); 
// // //     const [rewardDiscription, setRewardDiscription] = useState("");
// // //     const [rewardDate, setRewardDate] = useState("null");
// // //     const [rewardStatus, setRewardStatus] = useState("null");

// // //     const renderItem1 = (item) => {
// // //         return (
// // //             <TouchableOpacity style={styles.ActiveReward} onPress={() => setModalVisible1(!modalVisible1) & setRewardName(item.title) & setRewardTarget(item.target) & setRewardDiscription(item.description) & setRewardDate(item.date) & setRewardStatus(item.stat)} >
// // //                 <View style={{ flexDirection: 'row', justifyContent: 'flex-start', }}>
// // //                     <View style={{ width: '60%', flexDirection: 'row', }}>
// // //                         <MaterialCommunityIcons name="license" size={20} color="#fff" />

// // //                         <Text numberOfLines={1} style={styles.title1}>{item.title}</Text>
// // //                     </View>
// // //                     <Text style={styles.title2}>{item.target}</Text>
// // //                 </View>
// // //                 <Text style={styles.title3}>{item.date}</Text>

// // //             </TouchableOpacity>
// // //         )
// // //     }



// // //     return (
// // //         <View style={styles.container}>
// // //             <View style={{ flex:1 }}>
// // //             <FlatList
// // //   ItemSeparatorComponent={
// // //     Platform.OS !== 'android' &&
// // //     (({ highlighted }) => (
// // //       <View
// // //         style={[
// // //           style.separator,
// // //           highlighted && { marginLeft: 0 }
// // //         ]}
// // //       />
// // //     ))
// // //   }
// // //   data={[{ title: 'Title Text', key: 'item1' }]}
// // //   renderItem={({ item, index, separators }) => (
// // //     <TouchableHighlight
// // //       key={item.key}
// // //       onPress={() => this._onPress(item)}
// // //       onShowUnderlay={separators.highlight}
// // //       onHideUnderlay={separators.unhighlight}>
// // //       <View style={{ backgroundColor: 'white' }}>
// // //         <Text>{item.title}</Text>
// // //       </View>
// // //     </TouchableHighlight>
// // //   )}
// // // />
// // //             </View>

// // //             <Modal

// // //                 transparent={true} visible={modalVisible1} animationType='slide' >
// // //                 <View style={styles.modalView}  >
// // //                     <View style={{ width: '100%', height: 70,borderTopLeftRadius:20,borderTopRightRadius:20, flexDirection:'row',borderBottomWidth:.5,backgroundColor:'#040d50',}}>

// // //                         <View style={{width:'80%',justifyContent:'center',}}>
// // //                             <Text style={{fontSize:20, color:'#f49f1c',marginLeft:10,}}>Previous  Reward</Text>

// // //                         </View>
// // //                         <View style={{width:'20%',justifyContent:'center',}}>
// // //                             <Entypo name="cross" size={24} color="#f49f1c" style={{ alignSelf: 'flex-end',marginRight:5 }} onPress={() => setModalVisible1(!modalVisible1)} />
// // //                         </View>
// // //                     </View>
// // //                     <View style={{ flexDirection: 'row', justifyContent: 'space-around',padding:10 }}>



// // //                         <View style={{ justifyContent: 'center', }}>
// // //                             <Text style={{fontSize:17,}}>{rewardName}</Text>

// // //                         </View>

// // //                         <View style={{ justifyContent: 'center', marginRight: 25, }}>
// // //                             <Text style={{ fontSize: 15, fontWeight: 'bold', }}>{rewardTarget}</Text>
// // //                         </View>

// // //                     </View>

// // //                     <View style={{ justifyContent: 'center', flexDirection: 'row', height: 50, padding: 10, alignItems: 'center',}}>
// // //                         <Text style={{ alignSelf: 'center', }}>Sale Target {saleTarget}</Text>
// // //                         <Text></Text>
// // //                     </View>


// // //                     <View style={{ justifyContent: 'center', flexDirection: 'row', padding: 10, alignItems: 'center', }}>
// // //                         <Text style={{ alignSelf: 'center',textAlign:'justify' }}>{rewardDiscription}</Text>
// // //                         <Text></Text>
// // //                     </View>

// // //                     <View style={{ justifyContent: 'center', flexDirection: 'row', height: 50, padding: 10, alignItems: 'center', }}>
// // //                         <Text >{rewardDate}</Text>
// // //                     </View>



// // //                 </View>
// // //             </Modal>

// // //         </View>
// // //     )

// // // }

// // // const styles = StyleSheet.create({
// // //     container: {
// // //         flex:1,
// // //     },
// // //     ActiveReward: {
// // //         width: '90%',
// // //         height: 80,
// // //         backgroundColor: '#040d50',
// // //         // marginLeft: 10,
// // //         marginBottom:10,
// // //         marginTop: 10,
// // //         padding: 10,
// // //         borderRadius: 15,
// // //         alignSelf:'center',
// // //     },

// // //     modalView: {
// // //         // marginLeft: '45%',
// // //         marginTop: '60%',
// // //         width: '90%',
// // //         // height: '40%',
// // //         //  borderRadius: 7,
// // //         backgroundColor: "#fff",
// // //         borderRadius: 20,
// // //         alignSelf: 'center',
// // //         shadowColor: "#000",
// // //         shadowOffset: {
// // //             width: 0,
// // //             height: 2
// // //         },
// // //         shadowOpacity: 0.25,
// // //         shadowRadius: 4,
// // //         elevation: 5
// // //     },

// // //     title1: {
// // //         fontSize: 16,
// // //         marginLeft: 5,
// // //         fontWeight: 'bold',
// // //         color: '#fff',
// // //         width:'90%',
// // //     },

// // //     title2: {
// // //         width: 80,
// // //         marginLeft: '20%',
// // //         color: '#fff',
// // //         alignSelf: 'center',

// // //     },
// // //     title3: {
// // //         color: '#fff',
// // //         marginTop:20,
// // //         textAlign: 'center',
// // //     },
// // // });


// // import React, { useState } from 'react'
// // import { Text, View, StyleSheet, FlatList, TouchableOpacity,Modal,Button } from 'react-native'
// // import { AntDesign, Entypo, Ionicons, FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';



// // const DATA1 = [
// // {id:'0',title:"Title 1"},
// // // {id:'1',title:"Title 2"},
// // ];




// // export default function Test() {

// //     const[count,setCount]=useState(0);
// //     const[counter,setCounter]='2';
// //     const renderItem1 = (item) => {
// //         return (
// //             <View style={{width:200,height:200,backgroundColor:randomRGB(),marginTop:10}}>
// //                 {/* <Text style={{color:"white",fontSize:20,marginTop:50}}>{item.title}</Text> */}
// //             </View>
// //         );
// //     }




// //     return (
// //         <View style={styles.container}>
// //             <View style={{ flex:1 }}>
// //                 <FlatList
// //                     horizontal={false}
// //                     showsVerticalScrollIndicator={false}
// //                     data={DATA1}
// //                     renderItem={({ item }) => renderItem1(item)}
// //                     keyExtractor={item => item.id}

// //                 />
// //             </View>
// //             {/* <TouchableOpacity onPress={()=> setCounter(counter+1) & DATA1.push({id:counter,title:"Title 3"}) & setCount(count+1)} style={{width:100,height:30,backgroundColor:'blue',justifyContent:'center',alignItems:'center',alignSelf:'center',}}>
// //                 <Text style={{color:'white'}}>Add</Text>
// //             </TouchableOpacity> */}



// //         </View>
// //     );

// // }


// // const randomRGB=()=>{
// //     const red=Math.floor(Math.random()*256);
// //     const green=Math.floor(Math.random()*256);
// //     const blue=Math.floor(Math.random()*256);
// // return 'rgb($(red),$(green),$(blue))';
// // };

// // const styles = StyleSheet.create({
// //     container: {
// //         flex:1,
// //     },

// // });
//  import React, { useState,useEffect } from 'react'
// import DateTimePicker from '@react-native-community/datetimepicker';
//  import { Text, View, StyleSheet,Button } from 'react-native'
//  import { EvilIcons } from '@expo/vector-icons';

// export default function Test  ()  {
//     const [date, setDate] = useState(new Date(1598051730000));
//     const [mode, setMode] = useState('date');
//     const [show, setShow] = useState(false);

//     const onChange = (event, selectedDate) => {
//       const currentDate = selectedDate;
//       setShow(false);
//       setDate(currentDate);
//     };

//     const showMode = (currentMode) => {
//       setShow(true);
//       setMode(currentMode);
//     };

//     const showDatepicker = () => {
//       showMode('date');
//     };

//     const showTimepicker = () => {
//       showMode('time');
//     };

//     return (
//       <View style={styles.container}>
//         <View>
//           {/* <Button onPress={showDatepicker} title="Show date picker!" /> */}
//           <EvilIcons onPress={showDatepicker} name="calendar" size={24} color="black" />

//         </View>

//         <Text>selected: {date.toLocaleDateString()}</Text>
//         {show && (
//           <DateTimePicker
//             testID="dateTimePicker"
//             value={date}
//             mode={mode}
//             display="default"
//             is24Hour={true}
//             dateFormat="day month year"
//             // value={new Date()}
//             onChange={onChange}
//           />
//         )}
//       </View>
//     );
//   }
//   const styles = StyleSheet.create({
//          container: {
//              flex:1,
//              justifyContent: 'center',
//              alignItems: 'center',
//          },

//      });


import React ,{useEffect}from 'react'
import { View, Text } from 'react-native'

export default function Test() {


  useEffect(() => {
    getDataUsingGet(111)
  }, [])
  
  const getDataUsingGet = (emp_id) => {
    const formData = new FormData()
    formData.append('user_id', emp_id);

    try {
      fetch( 'http://eboard.qubitars.com/api/view_reminder', {
        method: 'POST',
        headers: {
          Accept: "application/json",
          "Content-Type": "multipart/form-data",
        },
        body: formData
      })
        .then((response) => response.json())
        .then((responseJson) => {

          if (responseJson.error) {
            alert(responseJson.error_msg);
          } else {

            try {
              console.log(responseJson)
            } catch (error) {
              console.log(error)
            }

          }

        })
        .catch((error) => {
          alert(error)
        });
    } catch (e) {
      alert(e)
    }
  };


  return (
    <View>
      <Text>Test</Text>
    </View>
  )
}