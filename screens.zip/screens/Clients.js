import React, { useState } from 'react'
import { View, Text, TouchableOpacity, StyleSheet, FlatList, Image, TextInput } from 'react-native'
import Header from './Header'
import { Button, Overlay } from 'react-native-elements';
import { Entypo, Feather, FontAwesome5, FontAwesome, MaterialCommunityIcons, MaterialIcons, EvilIcons,Fontisto } from '@expo/vector-icons';
import TabContainer from './TabContainer';

export default function Clients({ navigation }) {
    const Data = [
        {
            name: 'Sajjad',
            email: 'Sajjad@gmail.com',
            contact: '00000000000',
            organizationName: 'Qubitars.Ltv',
            address: 'Gift University Chock Pindi Bypas Gujranwala Punjab Pakistan'
        },
        {
            name: 'Sajjad',
            email: 'Sajjad@gmail.com',
            contact: '00000000000',
            organizationName: 'Qubitars.Ltv',

            address: 'Gift University Chock Pindi Bypas Gujranwala Punjab Pakistan'
        },
        {
            name: 'Sajjad',
            email: 'Sajjad@gmail.com',
            contact: '00000000000',
            organizationName: 'Qubitars.Ltv',

            address: 'Gift University Chock Pindi Bypas Gujranwala Punjab Pakistan'
        },
        {
            name: 'Sajjad',
            email: 'Sajjad@gmail.com',
            contact: '00000000000',
            organizationName: 'Qubitars.Ltv',

            address: 'Gift University Chock Pindi Bypas Gujranwala Punjab Pakistan'
        },
        {
            name: 'Sajjad',
            email: 'Sajjad@gmail.com',
            contact: '00000000000',
            organizationName: 'Qubitars.Ltv',

            address: 'Gift University Chock Pindi Bypas Gujranwala Punjab Pakistan'
        },
        {
            name: 'Sajjad',
            email: 'Sajjad@gmail.com',
            contact: '00000000000',
            organizationName: 'Qubitars.Ltv',

            address: 'Gift University Chock Pindi Bypas Gujranwala Punjab Pakistan'
        },
        {
            name: 'Sajjad',
            email: 'Sajjad@gmail.com',
            contact: '00000000000',
            organizationName: 'Qubitars.Ltv',

            address: 'Gift University Chock Pindi Bypas Gujranwala Punjab Pakistan'
        },
    ]
    const [detail, setDetail] = useState({
        name: '',
        email: '',
        contact: '',
        organizationName: '',

    })
    const [visible, setVisible] = useState(false);
    const toggleOverlay = () => {
        setVisible(!visible);
    };
    const renderItem = (item, index) => {
        return (
            <View style={styles.card}>

                <View style={{ height: '100%', width: 100, }}>
                    <View style={{ width: 80, height: 100, borderRadius: 300, alignSelf: 'center', }}>
                        <Image source={require('../assets/img.jpg')} resizeMode='cover' style={{ width: 70, height: 70, alignSelf: 'center', marginTop: '20%', borderRadius: 50, }} />
                    </View>

                </View>

                <View style={{ flex: 1, padding: 10, justifyContent: 'space-evenly', }}>


                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '90%', }}>

                        <Text style={{ fontWeight: 'bold', fontSize: 19, color: '#f49f1c', }}>
                            {item.name}
                        </Text>
                    </View>


                    <View style={{ flexDirection: 'row', }} >
                        <Entypo name="network" size={15} color="white" />
                        <Text style={{ color: '#fff', flexDirection: 'row', marginLeft: 10, alignSelf: 'center', }}>
                            {item.organizationName}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row', }} >
                        <Entypo name="email" size={15} color="white" />
                        <Text style={{ color: '#fff', flexDirection: 'row', marginLeft: 10, alignSelf: 'center', }}>
                            {item.email}
                        </Text>
                    </View>



                    <View style={{ flexDirection: 'row', }}>
                        <MaterialCommunityIcons name="phone" size={15} color="white" />
                        <Text style={{ color: '#fff', marginLeft: 10, }}>{item.contact}</Text>
                    </View>

                    <View style={{ flexDirection: 'row', }}>
                        <Entypo name="location-pin" size={15} color="white" />
                        {/* <Text style={{ color: '#fff', marginLeft: 10, alignSelf: 'center', }}>{item.credentialUrl}</Text> */}
                        <Text style={{ color: '#fff' }}>{item.address}</Text>
                    </View>

                    <View style={{ width: '100%', height: 50, flexDirection: 'row', marginBottom: -25, }}>
                        <TouchableOpacity onPress={() => { setDetail({ ...detail, cname: item.name, email: item.email, contact: item.contact, organizationName: item.organizationName, }) }}
                            style={{ width: 70, height: 35, borderRadius: 20, backgroundColor: '#f49f1c', justifyContent: 'space-evenly', alignItems: 'center', flexDirection: 'row', }}>
                            <FontAwesome name="pencil-square-o" size={20} color="#040d50" />
                            <Text style={{ fontSize: 16, color: '#040d50', fontWeight: 'bold', marginLeft: -5, }}>Edit</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ width: 70, height: 35, borderRadius: 20, marginLeft: 20, backgroundColor: '#f49f1c', alignItems: 'center', justifyContent: 'space-around', flexDirection: 'row', }}  >
                            <EvilIcons name="trash" size={24} color="red" style={{ marginLeft: -4, }} />
                            <Text style={{ fontSize: 15, color: '#040d50', fontWeight: 'bold', marginLeft: -10, }}>Delete</Text>
                        </TouchableOpacity>

                    </View>

                </View>


            </View>

        )
    }



    return (
        <View style={styles.container}>
            <Header navigation={navigation} />
            <View style={{ width: '100%', height: 30, marginTop: 5, justifyContent: 'center', borderBottomWidth: .5, }}>
                <Text style={{ color: 'black', alignSelf: 'center', fontSize: 16, }}>My Clients</Text>
            </View>

            {/* <ScrollView style={{ marginTop: 10, flex: 1, }} */}

            {/* refreshControl={
                            <RefreshControl
                                refreshing={refreshing}
                                onRefresh={onRefresh}
                            />
                        } */}
            {/* > */}
            {/* {flatListEmployee.length == 0 ? */}
            {/* <Image source={require('../assets/NoData.gif')} style={{ width: 250, height: 200, alignSelf: 'center' }} ></Image> */}
            {/* : */}

            <FlatList

                horizontal={false}
                showsVerticalScrollIndicator={false}
                data={Data}
                renderItem={({ item, index }) => renderItem(item, index)}
                keyExtractor={item => item.id}

            />
            {/* } */}
            {/* </ScrollView> */}


            <Overlay visible={visible} onBackdropPress={toggleOverlay} overlayStyle={{ width: '95%', height: 360,padding:0 }}>
                <View style={styles.header}>
                    <TouchableOpacity onPress={toggleOverlay} style={{ width: '20%', height: '100%', justifyContent: 'center', alignItems: 'flex-start', padding: 7 }}>
                        <Entypo name='cross' color='#fff' size={27} />
                    </TouchableOpacity>
                    <View style={{ width: '50%', height: '100%', justifyContent: 'center', alignItems: 'center' }}><Text style={{ color: '#fff', fontSize: 22 }}>Add Client</Text></View>
                    <View style={{ width: '20%', height: '100%', justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity onPress={()=>console.log(detail)}  style={{ width: '85%', height: '70%', alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 7, }}>
                            <Text style={{ fontSize: 16, color: '#1f2e4d' }}>Save</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={styles.field}>
                    <Feather name="user" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,name:txt})} placeholder='Enter your Full Name' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
                <View style={styles.field}>
                    <Fontisto name="email" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,email:txt})} keyboardType={'email-address'} placeholder='Enter your Email Address' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
                <View style={styles.field}>
                    <Feather name="phone" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,contact:txt})} keyboardType={'number-pad'} placeholder='Enter your Conatct' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
                <View style={styles.field}>
                    <Entypo name="network" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,organizationName:txt})} placeholder='Enter your Organization Name' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
                <View style={styles.field}>
                    <Entypo name="location" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,address:txt})} placeholder='Enter your Organization Name' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
            </Overlay>


            
            {/* <Overlay visible={visible} onBackdropPress={toggleOverlay1} overlayStyle={{ width: '95%', height: 310,padding:0 }}>
                <View style={styles.header}>
                    <TouchableOpacity onPress={toggleOverlay1} style={{ width: '20%', height: '100%', justifyContent: 'center', alignItems: 'flex-start', padding: 7 }}>
                        <Entypo name='cross' color='#fff' size={27} />
                    </TouchableOpacity>
                    <View style={{ width: '50%', height: '100%', justifyContent: 'center', alignItems: 'center' }}><Text style={{ color: '#fff', fontSize: 22 }}>Edit Client</Text></View>
                    <View style={{ width: '20%', height: '100%', justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity onPress={()=>console.log(detail)}  style={{ width: '85%', height: '70%', alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 7, }}>
                            <Text style={{ fontSize: 16, color: '#1f2e4d' }}>Save</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={styles.field}>
                    <Feather name="user" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,name:txt})} placeholder='Enter your Full Name' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
                <View style={styles.field}>
                    <Fontisto name="email" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,email:txt})} keyboardType={'email-address'} placeholder='Enter your Email Address' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
                <View style={styles.field}>
                    <Feather name="phone" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,contact:txt})} keyboardType={'number-pad'} placeholder='Enter your Conatct' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
                <View style={styles.field}>
                    <Entypo name="network" size={24} color="#f49f1c" />
                    <TextInput onChangeText={(txt) => setDetail({...detail,organizationName:txt})} placeholder='Enter your Organization Name' placeholderTextColor={'gray'} style={{ width: '90%', marginLeft: 10, paddingLeft: 5, }} />
                </View>
            </Overlay> */}

            <TouchableOpacity onPress={toggleOverlay} style={{
                justifyContent: "center", alignItems: "center",
                backgroundColor: "#f49f1c", width: 60, height: 60, borderRadius: 50,
                position: "absolute", right: 0, bottom: 0, marginRight: 10,
                marginBottom: 40,
            }}>
                <TouchableOpacity onPress={toggleOverlay}>
                    <MaterialIcons name="add" size={39} color="#ffff" />
                </TouchableOpacity>
            </TouchableOpacity>

          <View style={{width:'100%',}}>
            <TabContainer/>

          </View>


        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    ActiveReward1: {
        width: '90%',
        height: 200,
        backgroundColor: 'gray',
        flexDirection: 'row',
        alignSelf: 'center',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 10,
        marginTop: 10,
        marginBottom: 10,
        borderRadius: 15,
    },
    header: {
        width: '100%',
        height: '15%',
        backgroundColor: '#1f2e4d',
        flexDirection: 'row',
        justifyContent: 'space-around'
      },
    card: {
        width: '90%',
        height: 230,
        backgroundColor: '#040d50',
        alignSelf: 'center',
        marginTop: 10,
        flexDirection: 'row',
        borderRadius: 20,

    },
    field: {
        width: '95%',
        height: 50,
        backgroundColor: '#fff',
        marginTop: 10,
        alignSelf: 'center',
        padding: 10,
        borderWidth: 1,
        // borderColor:'#f49f1c',
        alignItems: 'center',
        borderRadius: 10,
        flexDirection: 'row',
    },
});