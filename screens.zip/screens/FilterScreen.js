import React, { useState } from 'react';
import { Text, View } from 'react-native';

export default function FilterScreen () {
  
    return (
      <View>
        <Text> This is Filter screen</Text>
      </View>
    );
  
}
